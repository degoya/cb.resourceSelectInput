ResourceSelectInput
===================

Author: Alexander Herling <kontakt@degoya.de>

Resource Select Custom Input type for modmore ContentBlocks.

Usage
-----
Install via MODX Package Manager

Documentation
-------------
https://github.com/degoya/cb.resourceSelectInput
