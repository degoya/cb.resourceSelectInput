<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'd16b4e8d1ae71eb915f350b0a127566f',
      'native_key' => 'resourceselectinput',
      'filename' => 'modNamespace/df5224cd326f5e7052af4ee398585bad.vehicle',
      'namespace' => 'resourceselectinput',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '71b407e662ff65f62cc4c87f0e0bc783',
      'native_key' => NULL,
      'filename' => 'modCategory/64c129aad559e2b2ccca87a20fbf3da0.vehicle',
      'namespace' => 'resourceselectinput',
    ),
  ),
);