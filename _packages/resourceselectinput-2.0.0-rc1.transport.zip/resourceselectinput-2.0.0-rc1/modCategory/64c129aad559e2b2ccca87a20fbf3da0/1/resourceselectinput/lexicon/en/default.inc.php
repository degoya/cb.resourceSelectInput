<?php
$_lang['resourceselectinput'] = "";
$_lang['resourceselectinput.name'] = "cb.resourceSelectInput";
$_lang['resourceselectinput.description'] = "Resource Select Box for modmore Contentblocks";